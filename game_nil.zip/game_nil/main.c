#include <stdio.h>
#include <stdlib.h>

int main()
{
    char pil, a, pil2, b, pil4;
    int pilih, pilih2, pilih3;
    do{


    printf("\n\n<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<\n");
    printf("                Game NIM             \n");
    printf(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>\n");
    printf("\n\n Pilih pemain pertama :");
    printf("\n 1. Anda sebagai player 1 :");
    printf("\n 2. Anda sebagai player 2 :");
    printf("\n Anda memilih :");
    scanf("%d", &pilih2);

    switch(pilih2){
    case 1:
        printf("\n********************************\n");
        printf("1. Jumlah Stik sama dengan 7\n");
        printf("2. Pemain Pertama adalah Human\n");
        printf("********************************\n");

        printf("\n Human Play, pilih salah satu :");
        printf("\n 1. 6-1");
        printf("\n 2. 5-2");
        printf("\n 3. 4-3");
        printf("\n Human memilih :");
        scanf("%d", &pilih);

        switch(pilih){
        case 1:
            printf("\n 1. 5-1-1");
            printf("\n 2. 4-2-1");
            printf("\n Agent memilih : 4-2-1");
            pil=a;
            break;

        case 2:
            printf("\n 1. 4-2-1");
            printf("\n 2. 3-2-2");
            printf("\n Agent memilih : 4-2-1");
            pil=a;
            break;

        case 3:
            printf("\n 1. 4-2-1");
            printf("\n 1. 3-3-1");
            printf("\n Agent memilih : 4-2-1");
            pil=a;
            break;
        }

        if(pil==a){
        printf("\n\n 1. 3-2-1-1");
        printf("\n Human memilih :");
        scanf("%d", &pilih);
        printf("\n\n 1. 2-2-1-1-1");
        printf("\n Agent memilih : 2-2-1-1-1");
        printf("\n Sorry...Kamu Kalah :)))))");
        printf("\n\n");
        }
        break;

        case 2:
            printf("\n********************************\n");
            printf("1. Jumlah Stik sama dengan 7\n");
            printf("2. Pemain Pertama adalah Agent\n");
            printf("********************************\n");

            printf("\n Agent Play, pilih salah satu :");
            printf("\n 1. 6-1");
            printf("\n 2. 5-2");
            printf("\n 3. 4-3");
            printf("\n Agent memilih : 6-1");

            printf("\n\n 1. 5-1-1");
            printf("\n 2. 4-2-1");
            printf("\n Human memilih :");
            scanf("%d", &pilih3);

            switch(pilih3){

            case 1:
                printf("\n\n 1. 4-1-1-1");
                printf("\n 2. 3-2-1-1");
                printf("\n Agent memilih : 4-1-1-1");
                printf("\n\n 1. 3-1-1-1-1");
                printf("\n Human memilih :");
                scanf("%d", &pilih);
                printf("\n\n 1. 2-1-1-1-1-1");
                printf("\n Agent memilih : 2-1-1-1-1-1");
                printf("\n Sorry...Kamu Kalah ^_^");
                break;

            case 2:
                printf("\n\n 1. 3-2-1-1");
                printf("\n Agent memilih : 3-2-1-1");
                printf("\n\n 1. 2-2-1-1-1");
                printf("\n Human memilih :");
                scanf("%d", &pilih);
                printf("\n Horrayyyy Kamu Menang ^_^");
                printf("\n\n");
                break;

            }
        }
        printf("\n Apakah Anda Ingin Main Lagi?");
        fflush(stdin);
        scanf("%c", &pil4);
    }while(pil4=='y' || pil4=='Y');
}
